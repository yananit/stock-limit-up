# 文件保存路径（修改为你电脑的路径）
SAVE_PATH = "D:/Thszt/"
# 请求头设置
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Referer": "https://www.iwencai.com/stockpick/search?rsh=3&preParams=&ts=1&f=1&querytype=&searchfilter=&tid=stockpick&qs=zhineng&w=%E6%B6%A8%E5%81%9C%EF%BC%9B"
}
# 同花顺接口
URL = "http://push2ex.eastmoney.com/getTopicZTPool"